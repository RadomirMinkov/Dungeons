package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class UserIsNotLoggedInException extends Exception {
    public UserIsNotLoggedInException(String message) {
        super(message);
    }
}

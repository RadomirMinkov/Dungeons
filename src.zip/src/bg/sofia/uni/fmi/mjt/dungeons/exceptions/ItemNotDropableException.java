package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class ItemNotDropableException extends Exception {
    public ItemNotDropableException(String message) {
        super(message);
    }
}

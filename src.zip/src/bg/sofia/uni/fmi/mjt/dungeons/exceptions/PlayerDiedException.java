package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class PlayerDiedException extends Exception {
    public PlayerDiedException(String message) {
        super(message);
    }
}

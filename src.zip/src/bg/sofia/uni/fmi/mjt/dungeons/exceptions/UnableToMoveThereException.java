package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class UnableToMoveThereException extends Exception {
    public UnableToMoveThereException(String message) {
        super(message);
    }
}

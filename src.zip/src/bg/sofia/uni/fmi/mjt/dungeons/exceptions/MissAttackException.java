package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class MissAttackException extends Exception {
    public MissAttackException(String message) {
        super(message);
    }
}

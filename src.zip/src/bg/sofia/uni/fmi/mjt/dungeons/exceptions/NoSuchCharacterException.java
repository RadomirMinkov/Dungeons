package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class NoSuchCharacterException extends Exception {
    public NoSuchCharacterException(String message) {
        super(message);
    }
}

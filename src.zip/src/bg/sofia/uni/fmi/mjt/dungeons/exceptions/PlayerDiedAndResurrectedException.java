package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class PlayerDiedAndResurrectedException extends Exception {
    public PlayerDiedAndResurrectedException(String message) {
        super(message);
    }
}

package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class NoMorePotionsException extends Exception {
    public NoMorePotionsException(String message) {
        super(message);
    }
}

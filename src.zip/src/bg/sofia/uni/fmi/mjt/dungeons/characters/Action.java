package bg.sofia.uni.fmi.mjt.dungeons.characters;

public enum Action {
    ATTACK_WITH_WEAPON,
    ATTACK_WITH_SPELL,
    DEFEND,
    POWER_UP
}

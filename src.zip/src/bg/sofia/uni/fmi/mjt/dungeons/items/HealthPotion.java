package bg.sofia.uni.fmi.mjt.dungeons.items;

import bg.sofia.uni.fmi.mjt.dungeons.utility.Constants;

public class HealthPotion extends Potion  {

    public HealthPotion() {
        super("healthPotion", Constants.FIFTY);
    }

}

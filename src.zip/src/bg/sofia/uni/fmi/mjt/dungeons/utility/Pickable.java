package bg.sofia.uni.fmi.mjt.dungeons.utility;

public interface Pickable {

}

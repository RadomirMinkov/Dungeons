package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class MinionDiedException extends Exception {
    public MinionDiedException(String message) {
        super(message);
    }
}

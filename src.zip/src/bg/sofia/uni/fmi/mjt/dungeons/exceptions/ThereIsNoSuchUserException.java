package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class ThereIsNoSuchUserException extends Exception {
    public ThereIsNoSuchUserException(String message) {
        super(message);
    }
}

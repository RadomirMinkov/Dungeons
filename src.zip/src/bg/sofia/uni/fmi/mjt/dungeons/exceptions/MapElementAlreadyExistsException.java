package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class MapElementAlreadyExistsException extends Exception {
    public MapElementAlreadyExistsException(String message) {
        super(message);
    }
}

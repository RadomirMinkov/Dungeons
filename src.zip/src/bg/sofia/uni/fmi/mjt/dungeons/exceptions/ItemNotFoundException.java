package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}

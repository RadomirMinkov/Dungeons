package bg.sofia.uni.fmi.mjt.dungeons.gamelogic;

public enum Mode {
    NORMAL,
    BATTLE,
    TRADE,
    TREASURE,
    CHOOSE
}

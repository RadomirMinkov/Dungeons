package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class EmptyInventoryException extends Exception {
    public EmptyInventoryException(String message) {
        super(message);
    }
}
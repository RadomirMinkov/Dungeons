package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class MapElementDoesNotExistException extends Exception {
    public MapElementDoesNotExistException(String message) {
        super((message));
    }
}

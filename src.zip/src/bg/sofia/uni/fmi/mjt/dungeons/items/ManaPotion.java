package bg.sofia.uni.fmi.mjt.dungeons.items;

import bg.sofia.uni.fmi.mjt.dungeons.utility.Constants;

public class ManaPotion extends Potion {

    public ManaPotion() {
        super("manaPotion", Constants.FIFTY);
    }
}

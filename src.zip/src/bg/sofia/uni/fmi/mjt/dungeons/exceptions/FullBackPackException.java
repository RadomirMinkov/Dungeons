package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class FullBackPackException extends Exception {
    public FullBackPackException(String message) {
        super(message);
    }
}

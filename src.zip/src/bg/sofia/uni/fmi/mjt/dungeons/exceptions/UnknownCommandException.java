package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class UnknownCommandException extends Exception {
    public UnknownCommandException(String message) {
        super(message);
    }
}

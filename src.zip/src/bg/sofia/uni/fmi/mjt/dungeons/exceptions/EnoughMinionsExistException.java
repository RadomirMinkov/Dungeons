package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class EnoughMinionsExistException extends Exception {
    public EnoughMinionsExistException(String message) {
        super(message);
    }
}

package bg.sofia.uni.fmi.mjt.dungeons.exceptions;

public class NotEnoughExperienceException extends Exception {
    public NotEnoughExperienceException(String message) {
        super(message);
    }
}
